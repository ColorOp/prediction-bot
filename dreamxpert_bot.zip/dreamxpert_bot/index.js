
const { Telegraf } = require('telegraf');
const axios = require('axios');
const schedule = require('node-schedule');

const bot = new Telegraf('7822340729:AAFQMAEK7WdOXTyCzmNGTacnfqLFWwr_T0I');

async function fetchMatchData() {
    const response = await axios.get('https://api.cricapi.com/v1/currentMatches?apikey=7f4cd2ab-2ecc-43f9-b9b2-83c2ddcaae73');
    return response.data;
}

function generateTeamMessage(match) {
    return `🏏 *DreamXpert Team Preview*
    
*Match:* ${match.name}
📅 *Date:* ${match.date}
🧤 *Wicketkeeper:* KL Rahul 🇮🇳
🧨 *Batters:* Virat Kohli 🇮🇳, David Warner 🇦🇺
🌀 *All-rounders:* Hardik Pandya 🇮🇳
🔥 *Bowlers:* Jasprit Bumrah 🇮🇳, Adam Zampa 🇦🇺

🥇 *Captain:* Virat Kohli
🥈 *Vice-Captain:* Hardik Pandya

🌦️ *Pitch Tip:* Batting-friendly surface with slight help for pacers.
💡 *Match Tip:* Prefer top-order batters from Team India.
`;
}

bot.command('team', async (ctx) => {
    const data = await fetchMatchData();
    const match = data.data[0];
    const message = generateTeamMessage(match);
    ctx.replyWithMarkdown(message);
});

// Schedule daily update at a fixed time for testing
schedule.scheduleJob('*/1 * * * *', async () => {
    const data = await fetchMatchData();
    const match = data.data[0];
    const message = generateTeamMessage(match);
    await bot.telegram.sendMessage('@Dream_Xpert_bot', message, { parse_mode: 'Markdown' });
});

bot.launch();
